// Select all slider items
let items = document.querySelectorAll('.slider .list .item');
// Select next and Next buttons
let next = document.getElementById('next');
let prev = document.getElementById('prev');
// Select all thumbnail items
let thumbnails = document.querySelectorAll('.thumbnail .item');

// Initialize variables
let countItem = items.length;// total number of slider items
let itemActive = 0;// current active slider item index

// Add event listener to next button
next.onclick = function(){
    itemActive = itemActive + 1;// Increment active item index
    // If active item index exceeds total items, reset to 0
    if(itemActive >= countItem){
        itemActive = 0;
    }
    showSlider();// Show the new active slider item
}
// Add event listener to previous button
prev.onclick = function(){
    itemActive = itemActive - 1; // Decrement active item index
   // If active item index is less than 0, set to last item index
    if(itemActive < 0){
        itemActive = countItem - 1;
    }
    showSlider();// Show the new active slider item
}
// Set interval to auto-advance slider every 3 seconds
let refreshInterval = setInterval(() => {
    next.click();
}, 3000)
// Function to show the active slider item
function showSlider(){
// Remove active class from old active item and thumbnail
    let itemActiveOld = document.querySelector('.slider .list .item.active');
    let thumbnailActiveOld = document.querySelector('.thumbnail .item.active');
    itemActiveOld.classList.remove('active');
    thumbnailActiveOld.classList.remove('active');

// Add active class to new active item and thumbnail
    items[itemActive].classList.add('active');
    thumbnails[itemActive].classList.add('active');

// Clear and reset interval to auto-advance slider every 5 seconds
    clearInterval(refreshInterval);
    refreshInterval = setInterval(() => {
        next.click();
    }, 3000)
}

// Add event listener to each thumbnail item
thumbnails.forEach((thumbnail, index) => {
    thumbnail.addEventListener('click', () => {
        // Set active item index to clicked thumbnail index
        itemActive = index;
        showSlider();
    })
})